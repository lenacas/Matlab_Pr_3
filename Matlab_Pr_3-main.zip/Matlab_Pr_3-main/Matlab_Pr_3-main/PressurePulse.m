%% Lena Castel-Wohnlich and Wolfgang Fuchs present: 
% Determination of ejection duration and flow model using pressure curves

%% Load Data, define important variables
clear;
close all;
load("Project3_02_Data.mat");
fs=250;                             %Sampling f; all freq in Hz
L= length(struct(1).pressure);      %Luckily all measurments of equal L
t= (0:L-1) *1/fs;

% Visualize data and spectra
% figure; hold on 
% plot(t,struct(1).pressure,t,struct(2).pressure,t,struct(3).pressure)
% legend("P1","P2","P3")
% [P1,f1]=calculateSpectrum(fft(struct(1).pressure),fs);
% [P2,f2]=calculateSpectrum(fft(struct(2).pressure),fs);
% [P3,f3]=calculateSpectrum(fft(struct(3).pressure),fs);
% figure; hold on
% subplot(3,1,1); semilogy(f1,P1); title("FFT of Signal #1"); xlabel("Frequency [Hz]")
% subplot(3,1,2); semilogy(f2,P2); title("FFT of Signal #2"); xlabel("Frequency [Hz]")
% subplot(3,1,3); semilogy(f3,P3); title("FFT of Signal #3"); xlabel("Frequency [Hz]")

% FFT suggests signal below and noise above 20Hz; 60Hz peak= powerline noise; 
% What is the 40Hz peak ?? Part of Signal? FIND OUT!!! ASK!!!
% Does it look better if filtered above 40 Hz? How should it look? 

%% 1. Filter High frequency noise and save in Struct
% Filter toolbox: Creation of Lowpass IIR filter with minimum order with fc =30 
% is onset distortion a problem? ASK!!! Different filter?
f_c_L=30;

for i=1:3
      struct(i).f_signal=filtfilt(IIR_Lowpass(f_c_L).sosMatrix, IIR_Lowpass(f_c_L).ScaleValues,struct(i).pressure);
end 

%% 2. Split to single beats
% using findpeaks, we detect the lowest values, where we assume a single
% beat starts. 

%Split filtered Signal
%carefully select peak distance in order to have similar splits with
% filtered and unfiltered signals
for i = 1:3
[peak_f, struct(i).location_f] = findpeaks(-struct(i).f_signal,t,'MinPeakDistance', 0.43);
struct(i).location_f = struct(i).location_f *fs/1;

for ii = 1:(length(struct(i).location_f)-1)
    a = struct(i).location_f(ii);
    b = struct(i).location_f(ii+1);
    struct(i).singlebeat_f(ii).signal = struct(i).f_signal(round(a):round(b));           % round to create integer
    struct(i).singlebeat_f(ii).time = (0:length(struct(i).singlebeat_f(ii).signal)-1) *1/fs;
end
end 

%Split unfiltered Signal
for i = 1:3
[peak, location] = findpeaks(-struct(i).pressure,t,'MinPeakDistance', 0.5);
location = location *fs/1;

for ii = 1:(length(location)-1)
    a = location(ii);
    b = location(ii+1);
    struct(i).singlebeat(ii).signal = struct(i).pressure(round(a):round(b));           % round to create integer
    struct(i).singlebeat(ii).time = (0:length(struct(i).singlebeat(ii).signal)-1) *1/fs;
end
end 


%% 3. Scale signal
% (determined for filtered and unfiltered signal (task 8.))
% by function: subtract minimum, divide by max, multiply with delta bp, 
% add diastolic bp;
% 1 Pa = 133,322 mmHg; Given pressure values  in mmHg; 
% Filtering distorted min/max values, but scaling should undo this
for i=1:3
    for ii = 1:(length(struct(i).singlebeat))
struct(i).singlebeat_f(ii).signal= scale_to_bp(struct(i).singlebeat_f(ii).signal,struct(i).sbp,struct(i).dbp);
struct(i).singlebeat(ii).signal=   scale_to_bp(struct(i).singlebeat(ii).signal,struct(i).sbp,struct(i).dbp);
    end
end

%% 4. Three-point-moving-average filter 
%(determined for filtered and unfiltered signal (task 8.))
% ASK! Order of assignment keept, but wouldnt it be smarter to filter and
% subsequently scale in order to avoid value distortion by the filter
% or should we recon the filter distortion as part of the assignemnt?

F=[1,1,1]/3;
for i=1:3
for ii = 1:(length(struct(i).singlebeat_f)-1)
   struct(i).singlebeat_f(ii).signal = filter(F,1,struct(i).singlebeat_f(ii).signal-struct(i).singlebeat_f(ii).signal(1))+struct(i).singlebeat_f(ii).signal(1);
   struct(i).singlebeat(ii).signal = filter(F,1,struct(i).singlebeat(ii).signal-struct(i).singlebeat(ii).signal(1))+struct(i).singlebeat(ii).signal(1);
end    
end


%% 5. Find and save Systolic peak (absolute maximum)
%(determined for filtered and unfiltered signal(task 8.))
for i = 1:3
for ii = 1:length(struct(i).singlebeat)
    [struct(i).singlebeat_f(ii).max,struct(i).singlebeat_f(ii).locmax] = max(struct(i).singlebeat_f(ii).signal);
    [struct(i).singlebeat(ii).max,struct(i).singlebeat(ii).locmax] = max(struct(i).singlebeat(ii).signal);
end
end

%% 6. Find and save Dicrotic notch 
%(determined for filtered and unfiltered signal(task 8.))
% Dicrotic notch equivalent to first local minimum after systolic peak

peakprominence=3; %very small with scaled signal
for i = 1:3
for ii = 1:length(struct(i).singlebeat)
    [struct(i).singlebeat_f(ii).dicrotic,struct(i).singlebeat_f(ii).locdic] = findpeaks(-struct(i).singlebeat_f(ii).signal,struct(i).singlebeat_f(ii).time,'MinPeakProminence',peakprominence);
    [struct(i).singlebeat(ii).dicrotic,struct(i).singlebeat(ii).locdic] = findpeaks(-struct(i).singlebeat(ii).signal,struct(i).singlebeat(ii).time,'MinPeakProminence',peakprominence);
end
end

%% 7. Ejection duration 
%(determined for filtered and unfiltered signal(8.))
% in seconds
struct(1).ejtimeav = 0; struct(1).ejtimeav_f = 0;
struct(2).ejtimeav = 0; struct(2).ejtimeav_f = 0;
struct(3).ejtimeav = 0; struct(3).ejtimeav_f = 0;

for i = 1:3
for ii = 1:length(struct(i).singlebeat_f)-1
   
    struct(i).ejtimeav = struct(i).ejtimeav + struct(i).singlebeat(ii).locdic;

    struct(i).ejtimeav_f = struct(i).ejtimeav_f + struct(i).singlebeat_f(ii).locdic;
end
    struct(i).ejtimeav = struct(i).ejtimeav/ii;
    struct(i).ejtimeav_f = struct(i).ejtimeav_f/ii;
end

%% 8. Repeat steps for unfiltered Signal 
% Were coded in above and saved in substructure "singlebeats"
% "singlebeats_f" contains the IIR lowpassfiltered signal 


%% Visualization and Testings
figure;
for j=1:3
    subplot(3,1,j); hold on;
    title("Filtered single beats #" +num2str(j));
for ii = 1:length(struct(j).singlebeat_f)-1
 
    plot(struct(j).singlebeat_f(ii).time,struct(j).singlebeat_f(ii).signal); 
    plot((struct(j).singlebeat_f(ii).locmax-1)/fs,struct(j).singlebeat_f(ii).max, 'x');
    plot(struct(j).singlebeat_f(ii).locdic,-struct(j).singlebeat_f(ii).dicrotic, 'o');
    xlabel("Time [s]"); ylabel("Pressure [mmHg]")
end
end
figure;
for j=1:3
    subplot(3,1,j); hold on;
    title("Single beats #" +num2str(j));
for ii = 1:length(struct(j).singlebeat_f)-1
 
    plot(struct(j).singlebeat(ii).time,struct(j).singlebeat(ii).signal); 
    plot((struct(j).singlebeat(ii).locmax-1)/fs,struct(j).singlebeat(ii).max, 'x');
    plot(struct(j).singlebeat(ii).locdic,-struct(j).singlebeat(ii).dicrotic, 'o');
    xlabel("Time [s]"); ylabel("Pressure [mmHg]")
end
end

% recognizable, that IIR filter distorts signal at beginning
% if thats a problem, filter in frequency domain?

% no dicrotic noth at 12th elements of filtered signal in struct(1)
figure
plot(struct(1).singlebeat_f(1).signal)
hold on
plot(struct(1).singlebeat_f(12).signal)
plot(struct(1).singlebeat(1).signal)
plot(struct(1).singlebeat(12).signal)
legend("f1","f12","og1","og12")
title("Some beats, the shorter f(1)12 causes problems")
% 12th elements is shorter, but why?
% its also not happening with the third signal? 


% recon: filtered signals match each other more closly 



